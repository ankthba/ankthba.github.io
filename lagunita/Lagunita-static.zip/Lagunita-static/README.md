# Lagunita

A screen-first Garamond in the Jannon line, with flared stems, chisel-cut
terminals, a tall lowercase and a taller t.
One variable font per style covers every weight and optical size.

- **Weight** `wght` 300–800: Light, Book, Regular, Medium, SemiBold, Bold, ExtraBold
- **Optical size** `opsz` 10–72: a sturdy Text cut (heavier hairlines, looser
  fit) up to a sharper, tighter Display cut
- **Roman and Italic**
- OpenType: kerning, ligatures and discretionary ligatures, small caps,
  oldstyle / lining / tabular figures, fractions, superiors, swash italics,
  stylistic sets, Latin, Greek, Cyrillic and Vietnamese

## On a website

Copy `web/` next to your CSS and link it:

```html
<link rel="stylesheet" href="/fonts/lagunita/lagunita.css">
```

```css
body { font-family: 'Lagunita', Georgia, serif; }
h1   { font-weight: 600; }            /* any value 300–800 */
em   { font-style: italic; }
```

Browsers pick the optical size from the font size on their own
(`font-optical-sizing: auto`), so 16px text gets the Text cut and a 72px
headline gets the Display cut. To pin it, set both properties. Safari ignores
the second while optical sizing is auto, and also under
`text-rendering: optimizeLegibility`, so keep that at `auto`:

```css
.hero { font-optical-sizing: none; font-variation-settings: 'opsz' 72; text-rendering: auto; }
```

`lagunita.css` splits each style by script with `unicode-range`, so a page
only downloads what it uses (about 100 KB roman, 125 KB italic for English).
It covers the core features. For small caps, superiors and every other
feature, use `full/` instead. Browsers without variable fonts fall back to
the static Text Regular; `lagunita-static.css` is a static-only set.

## On a computer

Install `variable/` (one file per style), or `static/` for apps that don't
handle variable fonts. The statics come in a Text and a Display family,
hinted for Windows.

## Licence

SIL Open Font License 1.1 (`OFL.txt`). Built from EB Garamond by Georg
Duffner and Octavio Pardo. Modifications by Aniketh Bandlamudi, 2026.
